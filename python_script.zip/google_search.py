import requests
from bs4 import BeautifulSoup
import pandas as pd

# Function to perform a search and scrape results from Google
def search_and_scrape(query):
    # Construct the search URL
    api_key = 'AIzaSyC32d6RbksLRKsO8WitmcIT-gYJAr3KyqQ'
    cx = '64407330f232c4720'
    search_url = f'https://www.googleapis.com/customsearch/v1?q={query}&key={api_key}&cx={cx}'

    # search_url = f"https://www.google.com/search?q={query.replace(' ', '+')}"

    # Send a request to fetch the HTML content
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    response = requests.get(search_url, headers=headers)
    response.raise_for_status()  # Check if the request was successful

    # Parse the HTML content using BeautifulSoup
    soup = BeautifulSoup(response.content, 'html.parser')
    search_results = response.json()
    # print(soup)
    # Define lists to store the data
    shop_names = []
    addresses = []
    phone_numbers = []
    emails = []

    # Scrape the search results
    items = search_results.get('items', [])
    # print(items)
    for item in items:
        title = item.get('title', 'N/A')
        snippet = item.get('snippet', 'N/A')
        link = item.get('link', 'N/A')

        # For demonstration purposes, assuming title contains shop name, and snippet contains address and phone number
        shop_names.append(title)
        addresses.append(snippet)
        link.append(link)
        phone_numbers.append('N/A')  # Placeholder for phone number extraction
        emails.append('N/A')  # Placeholder for email extraction

    # Create a DataFrame using the scraped data
    data = {
        'Shop Name': shop_names,
        'Address': addresses,
        'Link': link,
        'Phone Number': phone_numbers,
        'Email': emails
    }
    df = pd.DataFrame(data)

    # Save the DataFrame to an Excel file
    excel_file = f'{query.replace(" ", "_")}_search_results.xlsx'
    df.to_excel(excel_file, index=False)

    print(f"Data successfully scraped and saved to {excel_file}")

# Main function to take input from the user
def main():
    query = input("Enter your search query: ")
    search_and_scrape(query)

if __name__ == '__main__':
    main()
