from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import time

# Function to perform Google search and scrape results
def google_search(query):
    # Set up the WebDriver (ensure ChromeDriver path is correct)
    service = Service('C:\\Users\\www.abcom.in\\Downloads\\python\\driver\\chromedriver.exe')
    driver = webdriver.Chrome(service=service)


    # Open Google
    driver.get("https://www.google.com")
    time.sleep(5)
    driver.maximize_window()

    # Find the search box, enter the query, and hit Enter
    search_box = driver.find_element(By.NAME, 'q')
    search_box.send_keys(query)
    search_box.send_keys(Keys.RETURN)
    #driver.execute_script("window.scrollTo(100, document.body.scrollHeight);")
    time.sleep(2)

    element_to_click = driver.find_element(By.XPATH,"//div[@class='S8ee5 CwbYXd wHYlTd']")
    time.sleep(5)
 #   driver.execute_script("arguments[0].scrollIntoView();", element_to_click)
    driver.execute_script("window.scrollBy(0,100);",element_to_click.click())

    time.sleep(5)
    #element_to_click.click()
    time.sleep(5)
    # driver.find_element(By.CLASS_NAME, 'Z4Cazf OSrXXb').click()
        
        

        # # Wait for the results to load
        # wait = WebDriverWait(driver, 10)
        # wait.until(EC.presence_of_element_located((By.ID, "search")))

        # # Scrape the search results
        # titles = []
        # snippets = []
        # links = []

    results = driver.find_elements(By.XPATH, '//div[@jscontroller="AtSb"]')
    

    page_source = driver. execute_script("return document.documentElement.outerHTML;")
    print(page_source)
    #print(results.text)
    # for result in results:
    #     print(result.text)
        # for result in results:
        #     title_element = result.find_element(By.CSS_SELECTOR, 'h3')
        #     snippet_element = result.find_element(By.CSS_SELECTOR, 'span.aCOpRe')
        #     link_element = result.find_element(By.CSS_SELECTOR, 'a')

        #     titles.append(title_element.text)
        #     snippets.append(snippet_element.text)
        #     links.append(link_element.get_attribute('href'))

        # # Create a DataFrame using the scraped data
        # data = {
        #     'Title': titles,
        #     'Snippet': snippets,
        #     'Link': links
        # }
        # df = pd.DataFrame(data)

        # # Save the DataFrame to an Excel file
        # excel_file = f'{query.replace(" ", "_")}_search_results.xlsx'
        # df.to_excel(excel_file, index=False)
        # print(f"Data successfully scraped and saved to {excel_file}")

#        time.sleep(10)
 #       driver.quit()

# Main function to take input from the user
def main():
    query = input("Enter your search query: ")
    google_search(query)

if __name__ == '__main__':
    main()
